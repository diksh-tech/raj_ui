#!/bin/sh
# Force activate virtualenv to avoid overrides
export VIRTUAL_ENV=/opt/app-root/src/.venv
export PATH="$VIRTUAL_ENV/bin:$PATH"

exec "$@"

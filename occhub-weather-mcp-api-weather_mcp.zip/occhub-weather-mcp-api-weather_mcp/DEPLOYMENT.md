# METAR MCP Server - OpenShift Deployment Guide

## Prerequisites

### 1. **OpenShift Cluster Setup**
- OpenShift cluster running (version 4.6+)
- `oc` CLI tool installed and configured
- Access to create deployments, services, and configmaps

### 2. **MongoDB Database**
- MongoDB instance accessible from OpenShift cluster
- Database: `metar_data`
- Collection: `metar_data`
- Network connectivity from OpenShift to MongoDB

### 3. **Required Software**
- Docker (for building images)
- `oc` CLI (OpenShift command line tool)
- Access to OpenShift image registry

## Project Dependencies

### **Python Dependencies (auto-installed via Docker):**
- `mcp[cli]>=1.14.1` - Model Context Protocol
- `motor>=3.7.1` - Async MongoDB driver
- `pymongo>=4.15.1` - MongoDB driver
- `httpx>=0.28.1` - HTTP client

### **System Dependencies (included in Dockerfile):**
- Python 3.12
- curl (for uv installation)
- uv package manager

## Deployment Steps

### 1. **Build Docker Image**
```bash
# Build the image
docker build -t metar-mcp-server:latest .

# Tag for OpenShift registry (replace with your registry URL)
docker tag metar-mcp-server:latest your-registry.com/your-project/metar-mcp-server:latest

# Push to registry
docker push your-registry.com/your-project/metar-mcp-server:latest
```

### 2. **Deploy to OpenShift**
```bash
# Login to OpenShift
oc login your-openshift-cluster.com

# Create project (if not exists)
oc new-project metar-mcp

# Deploy MongoDB (if not already deployed)
oc new-app mongodb:latest --name=mongodb

# Deploy the application
oc apply -f openshift-deployment.yaml

# Check deployment status
oc get pods
oc get services
oc get configmaps
```

### 3. **Verify Deployment**
```bash
# Check pod logs
oc logs -f deployment/metar-mcp-server

# Check service connectivity
oc get svc metar-mcp-service

# Test MongoDB connection
oc exec -it deployment/metar-mcp-server -- python -c "
import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
async def test():
    client = AsyncIOMotorClient('mongodb://mongodb-service:27017')
    await client.admin.command('ping')
    print('MongoDB connection successful')
asyncio.run(test())
"
```

## Configuration

### **Environment Variables:**
- `MONGODB_URL` - MongoDB connection string
- `DATABASE_NAME` - Database name (default: metar_data)
- `COLLECTION_METAR` - Collection name (default: metar_data)

### **Resource Limits:**
- Memory: 256Mi request, 512Mi limit
- CPU: 100m request, 500m limit

## Security Considerations

### **OpenShift Security:**
- Runs as non-root user (UID 1001)
- Uses ConfigMaps for configuration
- Network policies can be applied
- Resource limits enforced

### **MongoDB Security:**
- Ensure MongoDB is accessible from OpenShift
- Consider using MongoDB authentication
- Use TLS for production deployments

## Monitoring and Logs

### **Health Checks:**
- Liveness probe: MongoDB connectivity test
- Readiness probe: MongoDB connectivity test
- Health check interval: 30 seconds

### **Logs:**
```bash
# View application logs
oc logs -f deployment/metar-mcp-server

# View specific pod logs
oc logs -f pod/metar-mcp-server-xxxxx
```

## Troubleshooting

### **Common Issues:**

1. **MongoDB Connection Failed:**
   - Check MongoDB service is running
   - Verify network connectivity
   - Check MongoDB URL configuration

2. **Pod Not Starting:**
   - Check resource limits
   - Verify image exists in registry
   - Check pod logs for errors

3. **MCP Server Not Responding:**
   - Verify MongoDB data exists
   - Check application logs
   - Test MongoDB connectivity

### **Debug Commands:**
```bash
# Check pod status
oc describe pod metar-mcp-server-xxxxx

# Check service endpoints
oc get endpoints metar-mcp-service

# Check configmap
oc get configmap metar-mcp-config -o yaml

# Access pod shell
oc exec -it deployment/metar-mcp-server -- /bin/bash
```

## Scaling

### **Horizontal Scaling:**
```bash
# Scale deployment
oc scale deployment metar-mcp-server --replicas=3

# Check scaled pods
oc get pods -l app=metar-mcp-server
```

### **Vertical Scaling:**
Update resource limits in `openshift-deployment.yaml`:
```yaml
resources:
  requests:
    memory: "512Mi"
    cpu: "200m"
  limits:
    memory: "1Gi"
    cpu: "1000m"
```

## Production Considerations

1. **Use persistent volumes for MongoDB data**
2. **Implement proper backup strategies**
3. **Set up monitoring and alerting**
4. **Use secrets for sensitive configuration**
5. **Implement proper network policies**
6. **Regular security updates**
